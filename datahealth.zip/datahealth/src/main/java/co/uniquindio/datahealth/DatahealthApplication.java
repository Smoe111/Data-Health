package co.uniquindio.datahealth;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DatahealthApplication {

	public static void main(String[] args) {
		SpringApplication.run(DatahealthApplication.class, args);
	}

}
