package co.uniquindio.datahealth;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DatahealthApplicationTests {

	@Test
	void contextLoads() {
	}

}
